/**
 * @fileoverview Petmate Insurance Modal Widget.
 *
 * @author oracle
 */
define(
    //-------------------------------------------------------------------
    // DEPENDENCIES
    // Adding knockout
    //-------------------------------------------------------------------
    ['jquery', 'knockout'],

    //-------------------------------------------------------------------
    // MODULE DEFINITION
    //-------------------------------------------------------------------
    function($, ko) {

        "use strict";

        return {

            onLoad: function(widget) {

            },

            beforeAppear: function(page) {


            }
        };
    }
);